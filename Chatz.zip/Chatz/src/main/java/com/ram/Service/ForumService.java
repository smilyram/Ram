package com.ram.Service;

import java.util.List;

import com.ram.model.Forum;

public interface ForumService {
	public void createNewForum(Forum forum);
	public List<Forum> getForumList(String forumUserName);
	public void delete(int forumId);
	public List<Forum> getForum();

}
