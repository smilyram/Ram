package com.ram.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ram.Dao.BlogDAO;
import com.ram.model.Blog;

public class BlogServiceImpl implements BlogService{
	@Autowired
	BlogDAO blogDao;
	@Override
	public void createNewBlog(Blog blog) {
		blogDao.createNewBlog(blog);
		
	}

	@Override
	public List<Blog> getBlogList(String bUserName) {
		return blogDao.getBlogList(bUserName);
	}

	@Override
	public Blog getBlogById(int bid) {
		return new Blog();
	}

	@Override
	public Blog getBlogByName(String bUsername) {
		return new Blog();
	}

	@Override
	public List<Blog> getBlog() {
		System.out.println("i am in blog serivce");
		return blogDao.getBlog();
	}

}
