package com.ram.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ram.Dao.ForumDAO;
import com.ram.model.Forum;

public class ForumServiceImpl implements ForumService{
	@Autowired
	ForumDAO forumDao;
	@Override
	public void createNewForum(Forum forum) {
		forumDao.createNewForum(forum);
		
		
	}

	@Override
	public List<Forum> getForumList(String forumUserName) {
		return forumDao.getForumList(forumUserName);
	}

	@Override
	public void delete(int forumId) {
		forumDao.delete(forumId);
		
	}

	@Override
	public List<Forum> getForum() {
		System.out.println("I am in forum service");
		return forumDao.getForum();
	}

}
