package com.ram.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ram.Dao.UserDAO;
import com.ram.model.User;
@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserDAO userDao;
	
	@Transactional
	public void saveOrUpdate(User user) {
		userDao.saveOrUpdate(user);
		
	}
	
	@Transactional
	public User getUserById(int userId) {
		return userDao.getUserById(userId);
	}
	
	@Transactional
	public List<User> list() {
		return userDao.list();
	}
	
	@Transactional
	public User getUserByname(String userName) {
		return userDao.getUserByName(userName);
	}

}
