package com.ram.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ram.Service.UserService;
import com.ram.model.User;




@Controller
public class HomeController 
{
	@Autowired
	UserService userService;
	
	@RequestMapping("/")
	public String LandPage()
	{
		System.out.println("home() method called");
		
		return "home";
	}
	@RequestMapping("/login")
	public String LoginP()
	{
		return "login";
	}
	@RequestMapping("/signUp")
	public ModelAndView RegPage()
	{	
		System.out.println("im in signup page");
		User user= new User();
		return new ModelAndView("signUp","user",user);
	}
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("user") User user , Model model,HttpServletRequest request,@RequestParam("image") MultipartFile file) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    
	    		user.setRole("ROLE_USER");
	    		user.setEnable(true);
	          
				userService.saveOrUpdate(user);
	    		System.out.println("Data Inserted");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		MultipartFile image = user.getImage();
	            //Path path;
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserId()+".jpg");
	           Path path=Paths.get("C://Users//MRuser//workspace6//Chatz//src//main//webapp//WEB-INF//resources//images//"+user.getUserId()+".jpg");
	    		System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image not saved");
	            	}
	            }
	    	
	     	    
	    return "login";
	
		
	}

}





