package com.ram.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ram.Service.UserService;

@Controller
public class HomeController {
	@Autowired
	UserService userserivce;

	ModelAndView mv;
	
	@RequestMapping("/")
	public ModelAndView LandPage()
	{
		System.out.println("home() method called");
		mv = new ModelAndView("home");
		return mv;
	}

}
