package com.ram.controller;




import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ram.Service.UserService;
import com.ram.model.User;

@Controller
public class HomeController 
{
	@Autowired
	UserService userService;
	
	@RequestMapping("/")
	public String LandPage()
	{
		System.out.println("home() method called");
		
		return "home";
	}
	@RequestMapping("/login")
	public String LoginP()
	{
		return "login";
	}
	@RequestMapping("/signUp")
	public ModelAndView RegPage()
	{	
		System.out.println("im in signup page");
		User user= new User();
		return new ModelAndView("signUp","user",user);
	}
	@RequestMapping(value="register", method=RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("user") User user,@RequestParam("file") MultipartFile file,BindingResult bindingResult) throws IllegalStateException, IOException
	{
		System.out.println("SignUp method called");
		MultipartFile image = file;
		System.out.println("file data:"+file);
		System.out.println("iTEM IMAGE:"+image);
		Path path = Paths.get("C://Users//MRuser//workspace6//Chatz//src//main//webapp//WEB-INF//resources//images//"+user.getUserId()+".jpg");

		System.out.println("Path:"+path);
		
		if(image != null && !image.isEmpty())
		{
			image.transferTo(new File(path.toString()));
			
		}
		
		System.out.println("successfully add the picture");

		if(bindingResult.hasErrors())
		{
			System.out.println(bindingResult);
			return new ModelAndView("signUp");
		}
		System.out.println("UserName:"+user.getUserName());
		System.out.println("Password:"+user.getPassword());
		System.out.println("Email:"+user.getEmail());
		System.out.println("Mobile:"+user.getMobile());
		System.out.println("Location:"+user.getLocation());
		System.out.println("Role:"+user.getRole());

		ModelAndView mv=new ModelAndView("login");
		userService.saveOrUpdate(user);
		mv.addObject("message","You have successfully Registered");
		return mv;
		
	}
}





